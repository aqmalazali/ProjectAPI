import { Component, OnInit } from '@angular/core';
import { BuyerService } from '../buyer.service'

@Component({
  selector: 'app-buyerlist',
  templateUrl: './buyerlist.component.html',
  styleUrls: ['./buyerlist.component.css']
})
export class BuyerlistComponent implements OnInit {

  constructor(private buyer: BuyerService) { }
  buyerData: any = [];
  ngOnInit(): void {
    this.buyer.getAllBuyer().subscribe((allData) => {
      console.log(allData);
      this.buyerData = allData;
    });
  }
  deletebuyer(buyer: any) {
    this.buyer.deleteBuyer(buyer).subscribe((result) => {
      //console.log(result);
      this.ngOnInit();
    });
  }

}
