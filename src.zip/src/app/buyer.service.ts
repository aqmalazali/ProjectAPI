import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {environment} from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class BuyerService {

  saveBuyerData(value: any) {
    return this.http.get(this.newUrl);
  }
  newUrl:any =environment.newURL;

  constructor(private http:HttpClient) { }

  getBuyer(){
    return this.http.get(this.newUrl);
  }

  addBuyer(data:any){
    return this.http.post(this.newUrl, data);
  }

  getAllBuyer(){
    return this.http.get(this.newUrl);
  }

  deleteBuyer(id:any){
    return this.http.delete(`${this.newUrl}/${id}`);
  }

  getBuyerById(id:any){
    return this.http.get(`${this.newUrl}/${id}`);
  }

  updateBuyerData(id:any, data:any){
    return this.http.put(`${this.newUrl}/${id}`, data);
  }
}
