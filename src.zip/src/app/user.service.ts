import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {environment} from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  saveUserData(value: any) {
    return this.http.get(this.baseUrl);
  }
  baseUrl:any =environment.baseURL;

  constructor(private http:HttpClient) { }

  getuser(){
    return this.http.get(this.baseUrl);
  }

  adduser(data:any){
    return this.http.post(this.baseUrl, data);
  }

  getAlluser(){
    return this.http.get(this.baseUrl);
  }

  deleteuser(id:any){
    return this.http.delete(`${this.baseUrl}/${id}`);
  }

  getuserById(id:any){
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  updateuserData(id:any, data:any){
    return this.http.put(`${this.baseUrl}/${id}`, data);
  }
}
