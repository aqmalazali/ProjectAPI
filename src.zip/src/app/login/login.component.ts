import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login:any = FormGroup;
  volunteer:any =[];
  constructor(private FormBuilder:FormBuilder, private router:Router, private userservice:UserService) { }

  ngOnInit(): void {
    this.login = this.FormBuilder.group({
      email:['',Validators.compose([Validators.required,Validators.email])],
      password:['',Validators.required]
    })

    this.userservice.getuser().subscribe((data:any)=>{
      console.log(data);
      this.volunteer = data;
    })
  }

    loginForm(data:any){
      console.log(data)
      if(data.email){
        this.volunteer.forEach((item:any) => {
          if(item.email == data.email && item.password == data.password){
            localStorage.setItem("isLoggedIn", "true");
            this.router.navigate(['home']);
          }
          else{
            localStorage.clear();
          }

        });

      }
  }

  gotToRegister(){
    this.router.navigate(['register']);
  }

}

