import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  public get userserv(): UserService {
    return this._userserv;
  }
  public set userserv(value: UserService) {
    this._userserv = value;
  }
register:any = FormGroup;
id:any;
  constructor(private FormBuilder:FormBuilder, private router:Router, private _userserv: UserService) { }

  ngOnInit(): void {
    this.register = this.FormBuilder.group({
      username:['', Validators.required],
      email:['', Validators.compose([Validators.required, Validators.email])],
      phoneNo:['', Validators.required],
      password:['', Validators.required]

    })
  }

  registerForm(data:any){
    console.log(data);
    let dataToPass = {
      username:data.username,
      email:data.email,
      phoneNo:data.phoneNo,
      password:data.password,
      id:this.id++
    }

    this.userserv.adduser(dataToPass).subscribe((data:any)=>{
      console.log(data);
    })
  }

  gotToLogin(){
    this.router.navigate(['login']);
  }
}

