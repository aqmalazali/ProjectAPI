import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AboutComponent } from './about/about.component';
import { PaymentComponent } from './payment/payment.component';
import { ClothingComponent } from './clothing/clothing.component';
import { FaqComponent } from './faq/faq.component';
import {HttpClientModule} from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SuccessComponent } from './success/success.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeloginComponent } from './homelogin/homelogin.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BuyerlistComponent } from './buyerlist/buyerlist.component';



@NgModule({
  declarations: [
    AppComponent,
    AboutComponent,
    PaymentComponent,
    ClothingComponent,
    FaqComponent,
    HomeComponent,
    NavbarComponent,
    SuccessComponent,
    LoginComponent,
    RegisterComponent,
    HomeloginComponent,
    BuyerlistComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
