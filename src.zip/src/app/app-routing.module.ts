import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AboutComponent } from './about/about.component';
import { PaymentComponent } from './payment/payment.component';
import { ClothingComponent } from './clothing/clothing.component';
import { HomeComponent } from './home/home.component';
import { FaqComponent } from './faq/faq.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SuccessComponent } from './success/success.component';
import {LoginComponent } from './login/login.component';
import {RegisterComponent } from './register/register.component';
import {HomeloginComponent } from './homelogin/homelogin.component';
import { AuthGuard } from './auth.guard';
import { BuyerlistComponent} from './buyerlist/buyerlist.component';

const routes: Routes = [
  {path: "about", component:AboutComponent},
  {path: "payment", component:PaymentComponent},
  {path: "clothing", component:ClothingComponent},
  {path: "faq", component:FaqComponent},
  {path: "home", component:HomeComponent},
  {path: "navbar", component:NavbarComponent},
  {path: "success", component:SuccessComponent},
  {path: "login", component:LoginComponent},
  {path: '', redirectTo:'login', pathMatch:"full"},
  {path: "register", component:RegisterComponent},
  {path: "homelogin", component:HomeloginComponent, canActivate:[AuthGuard]},
  {path: "buyerlist", component:BuyerlistComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
