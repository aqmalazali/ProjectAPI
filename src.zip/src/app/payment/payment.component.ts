import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BuyerService } from '../buyer.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  id: any;
  buyerserv: any;
  submit:any = FormGroup;
  addbuyer: any;
  message: boolean | undefined;
  // router: any;

  constructor(private buyer: BuyerService, private FormBuilder: FormBuilder, private router: Router) { }

  ngOnInit(): void {
    this.submit = this.FormBuilder.group({
    fullname:['', Validators.required],
    email:['', Validators.compose([Validators.required, Validators.email])],
    address:['', Validators.required],
    credit_card_number:['', Validators.required],
    year:['', Validators.required],
    cvv:['', Validators.required],
    // fullname: new FormControl (''),
    // email: new FormControl (''),
    // address: new FormControl (''),
    // credit_card_number: new FormControl (''),
    // year: new FormControl (''),
    // cvv: new FormControl (''),
  })
  }
  // SaveData() {
  //   //console.log(this.addBuyer.value);
  //   this.buyer.saveBuyerData(this.addbuyer.value).subscribe((result: any) => {
  //     console.log(result);
  //     this.message = true;
  //     this.addbuyer.reset({});
  //   });
  // }


  submitForm(data:any){
    console.log(data);
    let dataToPass = {
      fullname:data.fullname,
      email:data.email,
      address:data.address,
      credit_card_number:data.credit_card_number,
      year:data.year,
      cvv:data.cvv,
      id:this.id++
    }

    this.buyer.addBuyer(dataToPass).subscribe((data:any)=>{
      console.log(data);
    })
    this.router.navigate(['success']);
  // removeMessage() {
  //   this.message = false;
  // }

}
}
function submitForm(data: any, any: any) {
  throw new Error('Function not implemented.');
}

function data(data: any, any: any) {
  throw new Error('Function not implemented.');
}

